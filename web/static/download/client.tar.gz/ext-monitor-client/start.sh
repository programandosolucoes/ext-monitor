#!/bin/bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TARGET_IP="${1:-192.168.7.2}"
TARGET_PORT="${2:-5000}"
FPS="${3:-12}"
COLOR="${4:-256}"
HUD="${5:-hud}"

# Otimizar tamanho da fila USB (Buffer Bloat)
for iface in $(ip -o link show | awk -F': ' '{print $2}' | grep -E '^enx|^usb'); do
    sudo ip link set "$iface" txqueuelen 100 2>/dev/null || true
done

echo "[*] Iniciando ext-sender para $TARGET_IP:$TARGET_PORT ($FPS FPS, Cor: $COLOR, HUD: $HUD)..."
exec "$SCRIPT_DIR/ext-sender" "$TARGET_IP" "$TARGET_PORT" 0 extend auto "$FPS" "$HUD" "$COLOR"
