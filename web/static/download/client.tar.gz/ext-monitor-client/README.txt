========================================================================
Pi Zero GPU Display Engine • Cliente para PC (Linux / GNOME Wayland)
========================================================================

Instruções Rápidas:
1. Conecte o Raspberry Pi Zero à porta USB do seu PC.
2. Defina o IP estático 192.168.7.1 (máscara 255.255.255.0) na placa de rede USB (enx...).
3. No terminal, dentro desta pasta, execute:
   ./start.sh
4. O seu monitor HDMI secundário conectado ao Pi Zero iniciará instantaneamente!

Configurações e Telemetria:
Abra o navegador no seu PC e acesse:
   http://192.168.7.2:8080

Você poderá mudar FPS, Modo 256 Cores / TrueColor e reativar o HUD a quente com 1 clique!
